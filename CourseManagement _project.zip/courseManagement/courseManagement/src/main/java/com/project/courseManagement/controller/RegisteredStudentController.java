package com.project.courseManagement.controller;


import com.project.courseManagement.entity.RegisteredStudentDTO;
import com.project.courseManagement.entity.RegisteredStudentEntity;
import com.project.courseManagement.service.RegisteredStudentService;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.*;


import java.io.IOException;
import java.util.List;
@CrossOrigin(origins = "*")
@RestController
public class RegisteredStudentController {
    @Autowired
    private RegisteredStudentService registeredStudentService;


    @PostMapping("/registeredStudentEntity/post")
    public RegisteredStudentEntity createStudent(@RequestBody RegisteredStudentDTO studentDTO)
    {
        return registeredStudentService.addDetails(studentDTO);
    }


    @GetMapping("/registeredStudentEntity/get")
    public List<RegisteredStudentEntity> getAllDetails() {
        return registeredStudentService.getAllDetails();
    }

    @GetMapping("/registeredStudentEntity/getById/{id}")
    public List<RegisteredStudentEntity> getByUser(@PathVariable Long id) {
       return  registeredStudentService.getByUser(id);

    }

    @DeleteMapping("/registeredStudentEntity/delete/{id}")
    public void deleteDetails(@PathVariable Long id) {
        registeredStudentService.deleteDetails(id);
    }

    @PutMapping("/registeredStudentEntity/put/{id}")
    public RegisteredStudentEntity editDetails(@RequestBody RegisteredStudentEntity registeredStudentEntity, @PathVariable Long id) {
        return registeredStudentService.editDetails(registeredStudentEntity, id);
    }

    }
