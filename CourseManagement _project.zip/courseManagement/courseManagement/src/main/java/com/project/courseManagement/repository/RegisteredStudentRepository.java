package com.project.courseManagement.repository;

import com.project.courseManagement.entity.RegisteredStudentEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface RegisteredStudentRepository extends JpaRepository<RegisteredStudentEntity , Long> {
List<RegisteredStudentEntity> findByUserId(Long id);
}
