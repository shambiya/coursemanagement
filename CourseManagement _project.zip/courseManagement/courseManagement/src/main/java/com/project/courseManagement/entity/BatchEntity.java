package com.project.courseManagement.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;



@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data

@Table(name="Batch",uniqueConstraints = {@UniqueConstraint(columnNames = "batchSession")})
public class BatchEntity {
    @Id
    @GeneratedValue (strategy = GenerationType.AUTO)
    private Long   batchId;
    private String batchSession;




}
