package com.project.courseManagement.entity;

import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

import java.sql.Date;


public class StudentDto {

    private String courseName;
    private String courseSession;
    private CourseEntity courseEntity;
}
