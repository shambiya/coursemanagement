package com.project.courseManagement.exception;


public class FileNotFoundException extends RuntimeException{

    FileNotFoundException(String message)
    {
        super(message);
    }

}
