package com.project.courseManagement.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Date;


@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
public class RegisteredStudentEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private  Long studentId;
    private String studentName;
    private String studentEmailId;
    private String studentGender;
    private Long studentMobileNumber;
    private Date dateOfBirth;
    private String studentQualification;
    private String studentSpecialization;
    private  String studentAddress;
    private String studentCity;
    private String courseName;
    private String courseSession;
    private String courseDuration;
    private String courseFee;
    private String staffName;



    @ManyToOne
    @JoinColumn(name = "user_id" )
    private UserEntity  user;
}
