package com.project.courseManagement.entity;

import lombok.Getter;
import lombok.Setter;

import java.sql.Date;

@Getter @Setter
public class RegisteredStudentDTO {

    private String studentName;
    private String studentEmailId;
    private String studentGender;
    private Long studentMobileNumber;
    private Date dateOfBirth;
    private String studentQualification;
    private String studentSpecialization;
    private String studentAddress;
    private String studentCity;
    private String courseName;
    private String courseSession;
    private String courseDuration;
    private String courseFee;
    private String staffName;

    private Long user;


}
