package com.project.courseManagement.service;

import com.project.courseManagement.entity.BatchEntity;
import com.project.courseManagement.entity.CourseDto;
import com.project.courseManagement.entity.CourseEntity;
import com.project.courseManagement.repository.BatchRepository;
import com.project.courseManagement.repository.CourseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class CourseService {

    @Autowired
    private CourseRepository courseRepository;
    @Autowired
    private BatchRepository batchRepository;
    public List<CourseEntity> findAllByOrderByCourseStartingDateAsc() {
        return courseRepository.findAllByOrderByCourseStartingDateAsc();
    }

    public CourseEntity getCourseById(Long courseId) {
        return courseRepository.findById(courseId).orElse(null);
    }


    public CourseEntity updateCourse(Long courseId, CourseEntity courseDetails) {
        CourseEntity course = getCourseById(courseId);
        if (course != null) {
            course.setCourseName(courseDetails.getCourseName());
            course.setCourseDuration(courseDetails.getCourseDuration());
            course.setCourseStartingDate(courseDetails.getCourseStartingDate());
            course.setCourseEndingDate(courseDetails.getCourseEndingDate());
            course.setCourseFee(courseDetails.getCourseFee());
            course.setStaffName(courseDetails.getStaffName());

            return courseRepository.save(course);
        }
        return null;
    }

    public void deleteCourse(Long courseId) {
        courseRepository.deleteById(courseId);
    }


    public CourseEntity createCourse(CourseDto courseDto) {
        CourseEntity course = new CourseEntity();
        course.setCourseName(courseDto.getCourseName());
        course.setCourseDuration(courseDto.getCourseDuration());
        course.setCourseStartingDate(courseDto.getCourseStartingDate());
        course.setCourseEndingDate(courseDto.getCourseEndingDate());
        course.setCourseFee(courseDto.getCourseFee());
        course.setStaffName(courseDto.getStaffName());

        if (courseDto.getBatch() != null) {
            BatchEntity batch = null;
            if (courseDto.getBatch().getBatchId() != null) {
                batch = batchRepository.findById(courseDto.getBatch().getBatchId())
                        .orElse(null);
            }
            if (batch == null) {

                batch = batchRepository.findByBatchSession(courseDto.getBatch().getBatchSession());
                if (batch == null) {
                    batch = new BatchEntity();
                    batch.setBatchSession(courseDto.getBatch().getBatchSession());

                    batch = batchRepository.save(batch);
                }
            }
            course.setBatch(batch);
        }

        CourseEntity savedCourse = courseRepository.save(course);
        return courseRepository.save(course);
    }


}


