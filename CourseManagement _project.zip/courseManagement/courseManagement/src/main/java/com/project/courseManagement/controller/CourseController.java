package com.project.courseManagement.controller;

import com.project.courseManagement.entity.CourseDto;
import com.project.courseManagement.entity.CourseEntity;
import com.project.courseManagement.service.CourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.sql.Date;
import java.util.List;
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
public class CourseController {

    @Autowired
    private CourseService courseService;

    @GetMapping("courseEntity/get")
    public ResponseEntity<List<CourseEntity>> getAllCourses() {
        List<CourseEntity> courses = courseService.findAllByOrderByCourseStartingDateAsc();
        return new ResponseEntity<>(courses, HttpStatus.OK);
}

    @PostMapping("courseEntity/course")
public CourseEntity createCourse(@RequestBody CourseDto courseDto) {
        return courseService.createCourse(courseDto);
    }

    @GetMapping("courseEntity/getById{id}")
    public ResponseEntity<CourseEntity> getCourseById(@PathVariable Long id) {
        CourseEntity course = courseService.getCourseById(id);
        return new ResponseEntity<>(course, HttpStatus.OK);
    }

    @PutMapping("courseEntity/put/{id}")
    public ResponseEntity<CourseEntity> updateCourse(@PathVariable Long id, @RequestBody CourseEntity CourseEntity) {
        CourseEntity updatedCourse = courseService.updateCourse(id, CourseEntity);
        return new ResponseEntity<>(updatedCourse, HttpStatus.OK);
    }

    @DeleteMapping("courseEntity/delete/{id}")
    public ResponseEntity<Void> deleteCourse(@PathVariable Long id) {
        courseService.deleteCourse(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

}
