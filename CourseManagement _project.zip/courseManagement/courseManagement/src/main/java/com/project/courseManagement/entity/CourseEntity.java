package com.project.courseManagement.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;


import java.sql.Date;
import java.util.ArrayList;

import java.util.List;


@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
public class CourseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long courseId;
    private String courseName;
    private String courseDuration;
    @Temporal(TemporalType.DATE)
    private Date courseStartingDate;
    private Date courseEndingDate;
    private double courseFee;
    private String staffName;

    @ManyToOne(cascade={CascadeType.MERGE,CascadeType.REFRESH})
    @JoinColumn(name = "batch_fk")
    private BatchEntity batch;






}
