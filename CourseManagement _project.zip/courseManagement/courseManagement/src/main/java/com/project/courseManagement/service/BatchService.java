package com.project.courseManagement.service;

import com.project.courseManagement.entity.BatchEntity;
import com.project.courseManagement.entity.CourseEntity;
import com.project.courseManagement.repository.BatchRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BatchService {
    @Autowired
    private BatchRepository batchRepository;

    public void saveDetails(BatchEntity batchEntity) {
        batchRepository.save(batchEntity);
    }

    public List<BatchEntity> getAllDetails() {
        return batchRepository.findAll();
    }

    public void deleteDetails(Long id) {
        batchRepository.deleteById(id);
    }

    public void editDetails(BatchEntity batchEntity, Long id) {
        BatchEntity editDetails = batchRepository.findById(id).orElse(batchEntity);
        editDetails.setBatchSession(batchEntity.getBatchSession());
        batchRepository.save(editDetails);

    }
}
