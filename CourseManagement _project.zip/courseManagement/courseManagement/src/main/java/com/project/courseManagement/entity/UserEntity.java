package com.project.courseManagement.entity;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.HashSet;
import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "users",uniqueConstraints = {@UniqueConstraint(columnNames = "username"),
        @UniqueConstraint(columnNames = "email")})
public class UserEntity  {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    @Column(name = "userID")
    private Long id;

    @NotBlank
    @Size(max = 20)
    private String username;

    @NotBlank
    @Size(max = 50)
    @Email
    private String email;


    @Size(max = 120)
    private String password;

    @NotBlank
    @Size(max = 10)
    private String mobile;


    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(name = "user_roles",
            joinColumns = @JoinColumn(name="userId"),inverseJoinColumns=@JoinColumn(name = "roleId"))
    private Set<Role> roles=new HashSet<>();

    public UserEntity(String username, String password, String email,String mobile)
    {
        this.username=username;


        this.password=password;

        this.email=email;

        this.mobile=mobile;

    }
}
