package com.project.courseManagement.controller;

import com.project.courseManagement.entity.BatchEntity;

import com.project.courseManagement.service.BatchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
public class BatchController {
    @Autowired
    private BatchService batchService;

    @PostMapping("/batchEntity/post")
    public void saveDetails(@RequestBody BatchEntity batchEntity){
        batchService.saveDetails(batchEntity);
    }
    @GetMapping("/batchEntity/get")
    public List<BatchEntity> getAllDetails(){
        return  batchService.getAllDetails();
    }
    @DeleteMapping("/batchEntity/delete/{id}")
    public void deleteDetails(@PathVariable Long id){
        batchService.deleteDetails(id);
    }
    @PutMapping("/batchEntity/put/{id}")
    public void editDetails(@RequestBody BatchEntity batchEntity , @PathVariable Long id){
        batchService.editDetails(batchEntity,id);
    }





}
