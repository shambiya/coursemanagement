package com.project.courseManagement.entity;

public enum EnumRole {
    ADMIN,
    STUDENT
}
