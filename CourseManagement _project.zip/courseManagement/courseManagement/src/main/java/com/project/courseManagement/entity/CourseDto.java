package com.project.courseManagement.entity;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


import java.sql.Date;
@Getter @Setter
@AllArgsConstructor
@NoArgsConstructor
public class CourseDto {

    private Long courseId;
    private String courseName;
    private String courseDuration;
    private Date courseStartingDate;
    private Date courseEndingDate;
    private double courseFee;
    private String staffName;

    private BatchEntity batch;

    public  CourseDto (CourseEntity course){
        this.courseId=course.getCourseId();
        this.courseName=course.getCourseName();
        this.courseStartingDate=course.getCourseStartingDate();
        this.courseEndingDate=course.getCourseEndingDate();
        this.courseFee=course.getCourseFee();
        this.staffName=course.getStaffName();
        this.batch=course.getBatch();

    }











}
