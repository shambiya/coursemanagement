package com.project.courseManagement.service;


import com.project.courseManagement.entity.RegisteredStudentDTO;
import com.project.courseManagement.entity.RegisteredStudentEntity;
import com.project.courseManagement.entity.UserEntity;
import com.project.courseManagement.repository.RegisteredStudentRepository;
import com.project.courseManagement.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;



import java.util.List;
import java.util.Optional;

@Service
public class RegisteredStudentService {
    @Autowired
    private RegisteredStudentRepository registeredStudentRepository;
    @Autowired
    private UserRepository userRepository;

    public void saveDetails(RegisteredStudentEntity registeredStudentEntity) {
        Optional<UserEntity> userOpt=userRepository.findById(registeredStudentEntity.getUser().getId());

        RegisteredStudentEntity registeredStudent=new RegisteredStudentEntity();
        registeredStudent.setUser(userOpt.get());
        registeredStudentRepository.save(registeredStudentEntity);

    }

    public List<RegisteredStudentEntity> getAllDetails() {
        return  registeredStudentRepository.findAll();
    }


    public void deleteDetails(Long id) {
        registeredStudentRepository.deleteById(id);
    }

    public RegisteredStudentEntity editDetails(RegisteredStudentEntity registeredStudentEntity, Long id) {
        RegisteredStudentEntity editDetails = registeredStudentRepository.findById(id).orElse(registeredStudentEntity);
        editDetails.setStudentName(registeredStudentEntity.getStudentName());
        editDetails.setStudentEmailId(registeredStudentEntity.getStudentEmailId());
        editDetails.setStudentGender(registeredStudentEntity.getStudentGender());
        editDetails.setStudentMobileNumber(registeredStudentEntity.getStudentMobileNumber());
        editDetails.setStudentCity(registeredStudentEntity.getStudentCity());
        editDetails.setStudentAddress(registeredStudentEntity.getStudentAddress());
        editDetails.setDateOfBirth(registeredStudentEntity.getDateOfBirth());
        editDetails.setStudentSpecialization(registeredStudentEntity.getStudentSpecialization());
        editDetails.setStudentQualification(registeredStudentEntity.getStudentQualification());
        editDetails.setCourseSession(registeredStudentEntity.getCourseSession());
        editDetails.setCourseName(registeredStudentEntity.getCourseName());
        return registeredStudentRepository.save(editDetails);
       }

    public List<RegisteredStudentEntity> getByUser(Long id) {
        List<RegisteredStudentEntity>std= registeredStudentRepository.findByUserId(id);
        return std;
    }


    public RegisteredStudentEntity addDetails(RegisteredStudentDTO studentDTO) {

        Optional<UserEntity> userOpt=userRepository.findById(studentDTO.getUser());

        RegisteredStudentEntity studentEntity = new RegisteredStudentEntity();
        studentEntity.setUser(userOpt.get());
        studentEntity.setStudentName(studentDTO.getStudentName());
        studentEntity.setStudentEmailId(studentDTO.getStudentEmailId());
        studentEntity.setStudentGender(studentDTO.getStudentGender());
        studentEntity.setStudentMobileNumber(studentDTO.getStudentMobileNumber());
        studentEntity.setDateOfBirth(studentDTO.getDateOfBirth());
        studentEntity.setStudentQualification(studentDTO.getStudentQualification());
        studentEntity.setStudentSpecialization(studentDTO.getStudentSpecialization());
        studentEntity.setStudentAddress(studentDTO.getStudentAddress());
        studentEntity.setStudentCity(studentDTO.getStudentCity());
        studentEntity.setCourseName(studentDTO.getCourseName());
        studentEntity.setCourseSession(studentDTO.getCourseSession());
        studentEntity.setStaffName(studentDTO.getStaffName());
        studentEntity.setCourseFee(studentDTO.getCourseFee());
        studentEntity.setCourseDuration(studentDTO.getCourseDuration());
        return registeredStudentRepository.save(studentEntity);
    }
    }


